// const menuBtn = document.getElementById("menu-btn");
//   const mobileMenu = document.getElementById("mobile-menu");

//   menuBtn.addEventListener("click", () => {
//     mobileMenu.classList.toggle("hidden");
//   });

//   document.addEventListener("DOMContentLoaded", () => {
//   const userMenuBtn = document.getElementById("user-menu-btn");
//   const userMenu = document.getElementById("user-menu");

//   if (!userMenuBtn || !userMenu) return;

//   userMenuBtn.addEventListener("click", (e) => {
//     e.stopPropagation();
//     userMenu.classList.toggle("hidden");
//   });

//   document.addEventListener("click", () => {
//     userMenu.classList.add("hidden");
//   });
// });



// ------------------ Mobile Menu Toggle ------------------
const menuBtn = document.getElementById("menu-btn");
const mobileMenu = document.getElementById("mobile-menu");

menuBtn.addEventListener("click", () => {
  mobileMenu.classList.toggle("hidden");
});

// ------------------ User Menu Toggle ------------------
// document.addEventListener("DOMContentLoaded", () => {
//   const userMenuBtn = document.getElementById("user-menu-btn");
//   const userMenu = document.getElementById("user-menu");

//   if (!userMenuBtn || !userMenu) return;

//   // Get logged-in user from localStorage
//   const loginUser = JSON.parse(localStorage.getItem("loginUser"));

//   if (loginUser) {
//     // User is logged in - show Welcome message & Logout
//     userMenu.innerHTML = `
//       <p class="text-center px-4 py-2">Welcome, ${loginUser.name} ✅</p>
//       <button id="logoutBtn" class="block w-full text-center px-4 py-2 mt-1 text-sm text-white bg-red-500 hover:bg-red-600 rounded-md">
//         Logout
//       </button>
//     `;

//     document.getElementById("logoutBtn").addEventListener("click", () => {
//       localStorage.removeItem("loginUser");
//       window.location.reload(); // reload to show login/register again
//     });
//   } else {
//     // User not logged in - show Login/Register links
//     userMenu.innerHTML = `
//       <a href="login.html" class="block text-center px-4 py-2 text-sm text-gray-700 hover:bg-orange-100 rounded-md">Login</a>
//       <a href="registration.html" class="block text-center mt-1 px-4 py-2 text-sm text-white bg-[#ed563b] hover:bg-orange-600 rounded-md">Register</a>
//     `;
//   }

//   // Toggle dropdown on click
//   userMenuBtn.addEventListener("click", (e) => {
//     e.stopPropagation();
//     userMenu.classList.toggle("hidden");
//   });

//   // Hide dropdown when clicking outside
//   document.addEventListener("click", () => {
//     userMenu.classList.add("hidden");
//   });
// });


document.addEventListener("DOMContentLoaded", () => {
  const loginUser = JSON.parse(localStorage.getItem("loginUser"));
  const usernameDisplay = document.getElementById("username-display");
  const loginLink = document.getElementById("login-link");
  const registerLink = document.getElementById("register-link");
  const logoutLink = document.getElementById("logout-link");

  // Show welcome username and adjust links
  if (loginUser) {
    usernameDisplay.textContent = "Welcome, " + loginUser.name;
    usernameDisplay.classList.remove("hidden");

    loginLink.classList.add("hidden");
    registerLink.classList.add("hidden");
    logoutLink.classList.remove("hidden");
  }

  // Logout functionality
  logoutLink.addEventListener("click", () => {
    localStorage.removeItem("loginUser");
    window.location.href = "registration.html";
  });

  // Profile dropdown toggle
  const userMenuBtn = document.getElementById("user-menu-btn");
  const userMenu = document.getElementById("user-menu");

  if (userMenuBtn && userMenu) {
    userMenuBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      userMenu.classList.toggle("hidden");
    });

    document.addEventListener("click", () => {
      userMenu.classList.add("hidden");
    });
  }
});

