


let form = document.getElementById("loginform");
form.addEventListener("submit", async (e) => {
    e.preventDefault();
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    try {
        let response = await fetch("http://localhost:8000/user");
        if (!response.ok) throw new Error("Network response was not ok");
        let users = await response.json();

        let userFound = users.find(user => user.email === email && user.password === password);

        if (userFound) {
            alert("Login Successful ✅");
            localStorage.setItem("loginUser", JSON.stringify(userFound));
            window.location.href = "index.html";
        } else {
            alert("Invalid Email or Password ❌");
        }
    } catch (error) {
        console.error("Error:", error);
        alert("Server Error");
    }
});


