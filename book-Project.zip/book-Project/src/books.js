
let selectedCategory = "all";

function filterCategory(category) {
  selectedCategory = category;
  applyFilters();
}

document.getElementById("searchInput")?.addEventListener("input", applyFilters);

function applyFilters() {
  const searchText = document.getElementById("searchInput")?.value.toLowerCase() || "";
  const books = document.querySelectorAll(".book-card");

  books.forEach(book => {
    const title = book.dataset.name.toLowerCase();
    const category = book.dataset.category;

    const categoryMatch = selectedCategory === "all" || category === selectedCategory;
    const searchMatch = title.includes(searchText);

    book.style.display = (categoryMatch && searchMatch) ? "" : "none";
  });
}

/*****************************
  WISHLIST LOGIC
*****************************/
let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];

function toggleWishlist(book, heart) {
  const index = wishlist.findIndex(item => item.id === book.id);
  if(index === -1){
    wishlist.push(book);
    heart.textContent = "❤️";
  } else {
    wishlist.splice(index, 1);
    heart.textContent = "♡";
  }
  localStorage.setItem("wishlist", JSON.stringify(wishlist));
  renderWishlist();
}

function renderWishlist() {
  const container = document.getElementById("wishlistContainer");
  if(!container) return;

  container.innerHTML = "";

  if(wishlist.length === 0){
    container.innerHTML = `<p class="text-gray-500 text-sm">No items in wishlist</p>`;
    return;
  }

  wishlist.forEach(book => {
    const div = document.createElement("div");
    div.className = "flex items-start gap-3 mb-3 pb-2 wishlist-item";
    div.dataset.id = book.id; // important for removing
    div.innerHTML = `
      <img src="${book.image}" class="w-10 h-14 object-contain" />
      <div class="flex-1">
        <p class="text-sm font-medium">${book.title}</p>
        <p class="text-xs text-orange-500 mb-1">${book.price}</p>
        <div class="flex gap-2">
          <button class="remove-wishlist text-xs px-2 py-1 border rounded hover:bg-gray-100 w-[100px]" data-id="${book.id}">Remove</button>
          <button class="add-to-cart text-xs px-2 py-1 bg-[#ed563b] text-white rounded hover:bg-orange-600 w-[100px]" data-id="${book.id}">Add to Cart</button>
        </div>
      </div>
    `;
    container.appendChild(div);
  });
}

/*****************************
  RESTORE HEARTS ON RELOAD
*****************************/
function restoreHearts() {
  document.querySelectorAll(".book-card").forEach(card => {
    const heart = card.querySelector(".wishlist-btn");
    const id = card.dataset.name;
    if(wishlist.some(item => item.id === id)) heart.textContent = "❤️";
  });
}

/*****************************
  CART LOGIC
*****************************/
let cart = JSON.parse(localStorage.getItem('cart')) || [];
const cartCount = document.getElementById('cart-count');

function updateCartCount() {
  if(cartCount) cartCount.textContent = cart.reduce((acc, item) => acc + item.quantity, 0);
}

function addToCart(book){
  const existingItem = cart.find(item => item.id === book.id);
  if(existingItem) existingItem.quantity += 1;
  else cart.push({...book, quantity: 1});
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
  alert(`${book.title} added to cart 🛒`);
}

updateCartCount();

/*****************************
  EVENT LISTENERS
*****************************/
document.addEventListener("click", function(e){
  const card = e.target.closest(".book-card");

  // Wishlist heart click
  if(e.target.classList.contains("wishlist-btn") && card){
    const book = {
      id: card.dataset.name,
      title: card.querySelector("h3").innerText,
      price: card.querySelector(".text-orange-500").innerText,
      image: card.querySelector("img").src
    };
    toggleWishlist(book, e.target);
  }

  // Remove from wishlist
  if(e.target.classList.contains("remove-wishlist")){
    const id = e.target.dataset.id;

    // Remove from wishlist array & localStorage
    wishlist = wishlist.filter(item => item.id !== id);
    localStorage.setItem("wishlist", JSON.stringify(wishlist));

    // Remove only the clicked item from DOM
    const itemDiv = e.target.closest(".wishlist-item");
    if(itemDiv) itemDiv.remove();

    // If wishlist empty, show message
    if (wishlist.length === 0) {
      const container = document.getElementById("wishlistContainer");
      if(container) container.innerHTML = `<p class="text-gray-500 text-sm">No items in wishlist</p>`;
    }

    // reset heart icon on the main book card
    document.querySelectorAll(".book-card").forEach(card => {
      if(card.dataset.name === id){
        const heart = card.querySelector(".wishlist-btn");
        if(heart) heart.textContent = "♡";
      }
    });
  }

  // Add to cart
  if(e.target.classList.contains("add-to-cart")){
    const id = e.target.dataset.id;
    let book = wishlist.find(item => item.id === id) || null;
    if(!book && card){
      book = {
        id: card.dataset.name,
        title: card.querySelector("h3").innerText,
        price: card.querySelector(".text-orange-500").innerText,
        image: card.querySelector("img").src
      };
    }
    if(book) addToCart(book);
  }
});

/*****************************
  WISHLIST PANEL TOGGLE
*****************************/
const wishlistBtn = document.getElementById("wishlistBtn");
const wishlistContainer = document.getElementById("wishlistContainer");

if(wishlistBtn && wishlistContainer){
  wishlistBtn.addEventListener("click", e => {
    e.stopPropagation();
    wishlistContainer.classList.toggle("hidden");
  });

  document.addEventListener("click", e => {
    if(!wishlistContainer.contains(e.target) && !wishlistBtn.contains(e.target)){
      wishlistContainer.classList.add("");
    }
  });
}

restoreHearts();
renderWishlist();
