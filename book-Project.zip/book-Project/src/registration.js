
function showToast(message, color = "#ef4444") {
    Toastify({
        text: message,
        duration: 3000,
        gravity: "top",
        position: "right",
        close: true,
        style: {
            background: color
        }
    }).showToast();
}

let form = document.getElementById("reg-form-container");

form.addEventListener("submit", async (e) => {
    e.preventDefault();

    let name = document.getElementById("username").value.trim();
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value;
    let confirm = document.getElementById("sure").value;

    // 🔐 password match
    if (password !== confirm) {
        showToast("Passwords do not match ❌");
        return;
    }

    // 🔐 password length exactly 8
    if (password.length !== 8) {
        showToast("Password must be exactly 8 characters ❌");
        return;
    }

    try {
        // 🔍 CHECK USERNAME EXISTS
        let checkUsername = await fetch(`http://localhost:8000/user?name=${name}`);
        let existingUsername = await checkUsername.json();

        if (existingUsername.length > 0) {
            showToast("Username already exists, please enter a different username ❌");
            return;
        }

        // 🔍 CHECK EMAIL EXISTS
        let checkEmail = await fetch(`http://localhost:8000/user?email=${email}`);
        let existingEmail = await checkEmail.json();

        if (existingEmail.length > 0) {
            showToast("Email already exists, please try a different email ❌");
            return;
        }

        // ✅ REGISTER USER
        let userdata = { name, email, password };

        let response = await fetch("http://localhost:8000/user", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(userdata)
        });

      if (response.ok) {
    showToast("Registration successful ✅", "#22c55e");
    window.location.href = "login.html"; // direct redirect
}


    } catch (err) {
        console.error(err);
        showToast("Server error 🚨");
    }
});
