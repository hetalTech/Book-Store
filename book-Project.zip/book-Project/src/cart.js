
document.addEventListener('DOMContentLoaded', function(){
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartItemsContainer = document.getElementById('cart-items');
  const cartTotalEl = document.getElementById('cart-total');

  function renderCart(){
    cartItemsContainer.innerHTML = '';
    if(cart.length === 0){
      cartItemsContainer.innerHTML = '<p class="text-gray-500">Your cart is empty.</p>';
      cartTotalEl.textContent = '0';
      return;
    }

    let total = 0;
   cart.forEach((item, index) => {
  const priceNum = parseFloat(item.price.toString().replace(/₹/g, '')) || 0; // convert to number
  total += priceNum * item.quantity;

  const div = document.createElement('div');
  div.className = 'flex items-center gap-4 border-b pb-4';
  div.innerHTML = `
    <img src="${item.image}" class="w-16 h-20 object-contain" />
    <div class="flex-1">
      <p class="font-medium">${item.title}</p>
      <p class="text-orange-500">₹<span class="item-price">${(priceNum * item.quantity).toFixed(2)}</span></p>
      <div class="flex items-center gap-2 mt-1">
        <button class="decrease bg-gray-300 rounded w-[20px]" data-index="${index}">-</button>
        <span class="quantity">${item.quantity}</span>
        <button class="increase bg-gray-300 rounded w-[20px]" data-index="${index}">+</button>
        
      </div>
    </div>
    <button class="remove-item px-2 py-1 bg-[#ed563b] w-[100px] text-white rounded hover:bg-red-600" data-index="${index}">Remove</button>
  `;
  cartItemsContainer.appendChild(div);
});

    cartTotalEl.textContent = total.toFixed(2);
  }

// Quantity update
cartItemsContainer.addEventListener('click', function(e){
  const index = Number(e.target.dataset.index); // Convert string to number

  if(e.target.classList.contains('increase')){
    cart[index].quantity += 1;
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCart();
  }

  if(e.target.classList.contains('decrease')){
    if(cart[index].quantity > 1){
      cart[index].quantity -= 1;
      localStorage.setItem('cart', JSON.stringify(cart));
      renderCart();
    }
  }

  // Remove item
  if(e.target.classList.contains('remove-item')){
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCart();
  }
});


  // Place order
  document.getElementById('place-order').addEventListener('click', function(){
    if(cart.length === 0){
      alert("Your cart is empty!");
      return;
    }
    alert("Please Fill Your Details!");
    cart = [];
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCart();
  });

  

document.getElementById("place-order").addEventListener("click", () => {
  // redirect to customer details page
  window.location.href = "customerdetails.html";
});

  

  renderCart();
});
