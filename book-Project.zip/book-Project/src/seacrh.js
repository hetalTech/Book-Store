



function searchBooks() {
  let input = document.getElementById("searchBook").value.toLowerCase();
  let categories = document.querySelectorAll(".category-section");

  categories.forEach(category => {
    let books = category.querySelectorAll(".book-card");
    let categoryVisible = false;

    books.forEach(book => {
      let name = book.getAttribute("data-name").toLowerCase();

      if (name.includes(input)) {
        book.style.display = "flex";
        categoryVisible = true;
      } else {
        book.style.display = "none";
      }
    });

    // 🔥 Sirf us category ka h1 dikhao jisme book match hui
    category.style.display = categoryVisible ? "block" : "none";
  });
}

